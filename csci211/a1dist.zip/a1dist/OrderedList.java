package edu.olemiss.cs211.a1;


public class OrderedList<T extends Comparable<? super T>> extends List<T> {
	
	public void add(T o){
		
		return;
	}

}
